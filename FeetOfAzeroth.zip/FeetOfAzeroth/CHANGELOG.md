## Changelog — Feet Of Azeroth

### 0.1 — August 10, 2026
- Affichage de la distance de la session
- Affichage de la distance total
- Ajout des coordonnées GPS
- Un bouton toggle permet de basculer l'affichage
- ajout des unités du système métrique

### 0.2 - August 11, 2026
- code review
- ajout : sous-menu option
- ajout : fenêtre about
- ajout : switch entre yards et mètres
- bugfix : petit soucis avec les arrondis

### 0.3 - August 11, 2026
- GUI review
- ajout : affichage de la vitesse du joueur
- ajout : le bouton yd/m converti maintenant la distance ET la vitesse

### 0.4 - August 12, 2026
- ajout : bouton stats
- ajout : fenêtre stats
- ajout : bouton reset pour réinitialiser
- ajout : bouton achivevement pour voir les succès
- ajout : 3 succès
- ajout : fenêtre des succès

### 0.5 - Auguste 13, 2026
- ajout : 24 succès
- GUI Review
- Titre : Achivements X / Y
- L'unité choisie est sauvegardée 

## 0.6 - August 14, 2026
- bugfix : Correction du calcul de distance : prise en compte de l'axe Z

## 0.7 - August 18, 2026 (en test)
- Ouverture du projet à wow retail !
- fenêtre des stats déplaçable
- fenêtre des feats déplaçable
- code review
- affichage du temps passé AFK sur le podo
- affichage du temps passé mort ou en fantôme sur le podo
- les deux sont convertis en hh:mm:ss
- affichage du temps passé AFK dans la fenêtre des stats
- affichage du temps passé mort ou fantôme dans la fenêtre des stats













 